Metric,Task,Value,Unit
Cumulative indexing time of primary shards,,1.0670833333333334,min
Min cumulative indexing time across primary shards,,0.0020833333333333333,min
Median cumulative indexing time across primary shards,,0.012283333333333334,min
Max cumulative indexing time across primary shards,,1.0404333333333333,min
Cumulative indexing throttle time of primary shards,,0,min
Min cumulative indexing throttle time across primary shards,,0,min
Median cumulative indexing throttle time across primary shards,,0.0,min
Max cumulative indexing throttle time across primary shards,,0,min
Cumulative merge time of primary shards,,0.5711499999999999,min
Cumulative merge count of primary shards,,18,
Min cumulative merge time across primary shards,,0,min
Median cumulative merge time across primary shards,,0.0,min
Max cumulative merge time across primary shards,,0.5711499999999999,min
Cumulative merge throttle time of primary shards,,0,min
Min cumulative merge throttle time across primary shards,,0,min
Median cumulative merge throttle time across primary shards,,0.0,min
Max cumulative merge throttle time across primary shards,,0,min
Cumulative refresh time of primary shards,,0.75095,min
Cumulative refresh count of primary shards,,243,
Min cumulative refresh time across primary shards,,0.0020833333333333333,min
Median cumulative refresh time across primary shards,,0.025016666666666666,min
Max cumulative refresh time across primary shards,,0.6988333333333333,min
Cumulative flush time of primary shards,,0.0073,min
Cumulative flush count of primary shards,,7,
Min cumulative flush time across primary shards,,0,min
Median cumulative flush time across primary shards,,0.0006166666666666666,min
Max cumulative flush time across primary shards,,0.006066666666666666,min
Total Young Gen GC,,3.765,s
Total Old Gen GC,,0,s
Store size,,0.014128275215625763,GB
Translog size,,0.016070314683020115,GB
Heap used for segments,,0.12050819396972656,MB
Heap used for doc values,,0.016254425048828125,MB
Heap used for terms,,0.09002494812011719,MB
Heap used for norms,,0.0015869140625,MB
Heap used for points,,0.0,MB
Heap used for stored fields,,0.01264190673828125,MB
Segment count,,15,
Min Throughput,index-append,575.66,docs/s
Median Throughput,index-append,575.66,docs/s
Max Throughput,index-append,575.66,docs/s
50th percentile latency,index-append,783.7239990234375,ms
100th percentile latency,index-append,1077.2000732421875,ms
50th percentile service time,index-append,783.7239990234375,ms
100th percentile service time,index-append,1077.2000732421875,ms
error rate,index-append,0.00,%
Min Throughput,index-stats,72.79,ops/s
Median Throughput,index-stats,77.55,ops/s
Max Throughput,index-stats,81.66,ops/s
50th percentile latency,index-stats,1919.0122528076172,ms
90th percentile latency,index-stats,2458.6572265625,ms
99th percentile latency,index-stats,2765.244384765625,ms
99.9th percentile latency,index-stats,2878.2613525390625,ms
100th percentile latency,index-stats,2878.988525390625,ms
50th percentile service time,index-stats,9.097916762034098,ms
90th percentile service time,index-stats,22.01515293121338,ms
99th percentile service time,index-stats,34.607093811035156,ms
99.9th percentile service time,index-stats,73.57701492309766,ms
100th percentile service time,index-stats,82.21888732910156,ms
error rate,index-stats,0.00,%
Min Throughput,node-stats,48.17,ops/s
Median Throughput,node-stats,61.96,ops/s
Max Throughput,node-stats,79.81,ops/s
50th percentile latency,node-stats,1987.9651580414213,ms
90th percentile latency,node-stats,2546.6259765625,ms
99th percentile latency,node-stats,2696.84814453125,ms
99.9th percentile latency,node-stats,2720.6885986328125,ms
100th percentile latency,node-stats,2721.681396484375,ms
50th percentile service time,node-stats,8.136950370243618,ms
90th percentile service time,node-stats,22.12705421447754,ms
99th percentile service time,node-stats,36.25360107421875,ms
99.9th percentile service time,node-stats,61.32089233398473,ms
100th percentile service time,node-stats,62.8884391784668,ms
error rate,node-stats,0.00,%
Min Throughput,default,49.80,ops/s
Median Throughput,default,50.03,ops/s
Max Throughput,default,50.06,ops/s
50th percentile latency,default,7.019917906547079,ms
90th percentile latency,default,32.291651248931885,ms
99th percentile latency,default,93.56304550170898,ms
99.9th percentile latency,default,99.72248458862325,ms
100th percentile latency,default,100.56373596191406,ms
50th percentile service time,default,5.996362837878141,ms
90th percentile service time,default,18.660358174641924,ms
99th percentile service time,default,25.55701732635498,ms
99.9th percentile service time,default,33.10225868225115,ms
100th percentile service time,default,33.875823974609375,ms
error rate,default,0.00,%
Min Throughput,term,39.35,ops/s
Median Throughput,term,49.79,ops/s
Max Throughput,term,61.10,ops/s
50th percentile latency,term,13346.059790039062,ms
90th percentile latency,term,13607.9423828125,ms
99th percentile latency,term,13828.26318359375,ms
99.9th percentile latency,term,13840.28125,ms
100th percentile latency,term,13841.1669921875,ms
50th percentile service time,term,5.743794944551255,ms
90th percentile service time,term,21.982053629557292,ms
99th percentile service time,term,62.090768814086914,ms
99.9th percentile service time,term,125.11256408691742,ms
100th percentile service time,term,139.88624572753906,ms
error rate,term,0.00,%
Min Throughput,phrase,99.21,ops/s
Median Throughput,phrase,107.46,ops/s
Max Throughput,phrase,128.28,ops/s
50th percentile latency,phrase,2871.310106549944,ms
90th percentile latency,phrase,4686.318115234375,ms
99th percentile latency,phrase,4768.677978515625,ms
99.9th percentile latency,phrase,4781.306884765625,ms
100th percentile latency,phrase,4781.71923828125,ms
50th percentile service time,phrase,5.952238491603307,ms
90th percentile service time,phrase,21.899991035461426,ms
99th percentile service time,phrase,53.86875343322754,ms
99.9th percentile service time,phrase,122.51742172241782,ms
100th percentile service time,phrase,147.6697235107422,ms
error rate,phrase,0.00,%
Min Throughput,country_agg_uncached,4.01,ops/s
Median Throughput,country_agg_uncached,4.02,ops/s
Max Throughput,country_agg_uncached,4.02,ops/s
50th percentile latency,country_agg_uncached,8.062252521514893,ms
90th percentile latency,country_agg_uncached,10.639443397521973,ms
99th percentile latency,country_agg_uncached,38.60976791381836,ms
100th percentile latency,country_agg_uncached,48.76188659667969,ms
50th percentile service time,country_agg_uncached,6.991623878479004,ms
90th percentile service time,country_agg_uncached,8.895293235778809,ms
99th percentile service time,country_agg_uncached,32.907073974609375,ms
100th percentile service time,country_agg_uncached,41.97917175292969,ms
error rate,country_agg_uncached,0.00,%
Min Throughput,country_agg_cached,74.89,ops/s
Median Throughput,country_agg_cached,78.87,ops/s
Max Throughput,country_agg_cached,83.85,ops/s
50th percentile latency,country_agg_cached,3561.40860421317,ms
90th percentile latency,country_agg_cached,3915.2911376953125,ms
99th percentile latency,country_agg_cached,4074.5682373046875,ms
99.9th percentile latency,country_agg_cached,4098.651611328125,ms
100th percentile latency,country_agg_cached,4099.29931640625,ms
50th percentile service time,country_agg_cached,5.906845688819885,ms
90th percentile service time,country_agg_cached,20.960891723632812,ms
99th percentile service time,country_agg_cached,32.16371536254883,ms
99.9th percentile service time,country_agg_cached,96.44226074219375,ms
100th percentile service time,country_agg_cached,123.90714263916016,ms
error rate,country_agg_cached,0.00,%
Min Throughput,scroll,1.60,pages/s
Median Throughput,scroll,1.61,pages/s
Max Throughput,scroll,1.61,pages/s
50th percentile latency,scroll,113.38460922241211,ms
90th percentile latency,scroll,137.43470001220703,ms
99th percentile latency,scroll,242.55985260009766,ms
100th percentile latency,scroll,275.474853515625,ms
50th percentile service time,scroll,111.55850601196289,ms
90th percentile service time,scroll,134.6422348022461,ms
99th percentile service time,scroll,240.9180679321289,ms
100th percentile service time,scroll,274.64031982421875,ms
error rate,scroll,0.00,%
Min Throughput,expression,2.01,ops/s
Median Throughput,expression,2.01,ops/s
Max Throughput,expression,2.01,ops/s
50th percentile latency,expression,9.54465103149414,ms
90th percentile latency,expression,11.73991346359253,ms
99th percentile latency,expression,25.672314643859863,ms
100th percentile latency,expression,34.80528259277344,ms
50th percentile service time,expression,8.26628303527832,ms
90th percentile service time,expression,9.943596839904785,ms
99th percentile service time,expression,19.735283851623535,ms
100th percentile service time,expression,24.285720825195312,ms
error rate,expression,0.00,%
Min Throughput,painless_static,1.50,ops/s
Median Throughput,painless_static,1.51,ops/s
Max Throughput,painless_static,1.51,ops/s
50th percentile latency,painless_static,9.993743419647217,ms
90th percentile latency,painless_static,11.388816356658936,ms
99th percentile latency,painless_static,25.010030269622803,ms
100th percentile latency,painless_static,35.43192672729492,ms
50th percentile service time,painless_static,8.312082290649414,ms
90th percentile service time,painless_static,9.208208560943604,ms
99th percentile service time,painless_static,23.600727558135986,ms
100th percentile service time,painless_static,34.06768035888672,ms
error rate,painless_static,0.00,%
Min Throughput,painless_dynamic,1.50,ops/s
Median Throughput,painless_dynamic,1.51,ops/s
Max Throughput,painless_dynamic,1.51,ops/s
50th percentile latency,painless_dynamic,9.41454553604126,ms
90th percentile latency,painless_dynamic,11.63553762435913,ms
99th percentile latency,painless_dynamic,18.984041213989258,ms
100th percentile latency,painless_dynamic,25.270151138305664,ms
50th percentile service time,painless_dynamic,7.79969596862793,ms
90th percentile service time,painless_dynamic,9.732329368591309,ms
99th percentile service time,painless_dynamic,17.23641014099121,ms
100th percentile service time,painless_dynamic,23.133060455322266,ms
error rate,painless_dynamic,0.00,%
